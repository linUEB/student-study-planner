-- Create the database for IT Study Planner
CREATE DATABASE IF NOT EXISTS student_planner;

-- Use the database
USE student_planner;

-- Create the tasks table
CREATE TABLE IF NOT EXISTS study_tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    subject VARCHAR(100) NOT NULL,
    task_description TEXT NOT NULL,
    due_date DATE NOT NULL,
    priority ENUM('high', 'medium', 'low') DEFAULT 'medium',
    status ENUM('pending', 'in_progress', 'completed') DEFAULT 'pending',
    estimated_hours INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create index for faster queries
CREATE INDEX idx_subject ON study_tasks(subject);
CREATE INDEX idx_due_date ON study_tasks(due_date);
CREATE INDEX idx_status ON study_tasks(status);
CREATE INDEX idx_priority ON study_tasks(priority);

-- Sample data with IT-focused subjects
INSERT INTO study_tasks (subject, task_description, due_date, priority, estimated_hours) VALUES
('Cybersecurity', 'Complete lab exercise on encryption algorithms', '2023-12-15', 'high', 3),
('Networking', 'Configure virtual network using Cisco Packet Tracer', '2023-12-18', 'medium', 4),
('Programming', 'Finish Python data analysis project with Pandas', '2023-12-20', 'high', 5),
('Database Management', 'Design and implement a normalized database schema', '2023-12-22', 'medium', 3),
('Web Development', 'Build responsive React frontend for portfolio site', '2023-12-25', 'medium', 6),
('Cloud Computing', 'Deploy application to AWS using EC2 and S3', '2023-12-28', 'high', 4),
('Data Analytics', 'Create visualizations for sales data using Tableau', '2023-12-30', 'low', 2),
('AI & Machine Learning', 'Implement basic neural network with TensorFlow', '2024-01-05', 'high', 8),
('Software Engineering', 'Document software development lifecycle for project', '2024-01-08', 'medium', 3),
('IT Project Management', 'Prepare Gantt chart for semester project', '2024-01-10', 'low', 2),
('Computer Hardware', 'Research and compare latest CPU architectures', '2024-01-12', 'low', 2),
('Operating Systems', 'Study process scheduling algorithms', '2024-01-15', 'medium', 3);