<?php
// Start session for messages
session_start();

// Include database configuration
require_once 'config/database.php';

// Initialize database connection
$database = new Database();
$conn = $database->getConnection();

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['message'] = "No task specified for deletion";
    $_SESSION['message_type'] = "error";
    header("Location: index.php");
    exit;
}

$task_id = intval($_GET['id']);

// Verify the task exists before attempting deletion
try {
    $check_stmt = $conn->prepare("SELECT * FROM study_tasks WHERE id = :id");
    $check_stmt->bindParam(':id', $task_id);
    $check_stmt->execute();
    
    if ($check_stmt->rowCount() === 0) {
        $_SESSION['message'] = "Task not found or already deleted";
        $_SESSION['message_type'] = "error";
        header("Location: index.php");
        exit;
    }
} catch (PDOException $e) {
    $_SESSION['message'] = "Database error: " . $e->getMessage();
    $_SESSION['message_type'] = "error";
    header("Location: index.php");
    exit;
}

// Delete the task
try {
    // Prepare SQL statement
    $stmt = $conn->prepare("DELETE FROM study_tasks WHERE id = :id");
    
    // Bind parameters
    $stmt->bindParam(':id', $task_id);
    
    // Execute query
    if ($stmt->execute()) {
        $_SESSION['message'] = "Task deleted successfully!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Unable to delete task. Please try again.";
        $_SESSION['message_type'] = "error";
    }
} catch (PDOException $e) {
    $_SESSION['message'] = "Database Error: " . $e->getMessage();
    $_SESSION['message_type'] = "error";
}

// Redirect back to index page
header("Location: index.php");
exit;
?>