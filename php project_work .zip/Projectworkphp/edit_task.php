<?php
// Start session for potential future use
session_start();

// Include database configuration
require_once 'config/database.php';

// Initialize database connection
$database = new Database();
$conn = $database->getConnection();

// Initialize variables
$message = '';
$messageType = '';
$task = null;

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$task_id = intval($_GET['id']);

// Process form submission for update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_task'])) {
    // Validate and sanitize input
    $subject = htmlspecialchars(trim($_POST['subject']));
    $task_description = htmlspecialchars(trim($_POST['task']));
    $due_date = htmlspecialchars(trim($_POST['due_date']));
    $priority = isset($_POST['priority']) ? htmlspecialchars($_POST['priority']) : 'medium';
    $status = isset($_POST['status']) ? htmlspecialchars($_POST['status']) : 'pending';
    
    // Basic validation
    if (empty($subject) || empty($task_description) || empty($due_date)) {
        $message = "Please fill in all required fields";
        $messageType = "error";
    } else {
        try {
            // Prepare SQL statement
            $stmt = $conn->prepare("UPDATE study_tasks 
                                  SET subject = :subject, 
                                      task_description = :task, 
                                      due_date = :due_date, 
                                      priority = :priority,
                                      status = :status
                                  WHERE id = :id");
            
            // Bind parameters
            $stmt->bindParam(':subject', $subject);
            $stmt->bindParam(':task', $task_description);
            $stmt->bindParam(':due_date', $due_date);
            $stmt->bindParam(':priority', $priority);
            $stmt->bindParam(':status', $status);
            $stmt->bindParam(':id', $task_id);
            
            // Execute query
            if ($stmt->execute()) {
                $message = "Task updated successfully!";
                $messageType = "success";
                
                // Redirect after short delay
                header("Refresh: 2; URL=index.php");
            } else {
                $message = "Unable to update task.";
                $messageType = "error";
            }
        } catch (PDOException $e) {
            $message = "Database Error: " . $e->getMessage();
            $messageType = "error";
        }
    }
}

// Fetch the task data
try {
    $stmt = $conn->prepare("SELECT * FROM study_tasks WHERE id = :id");
    $stmt->bindParam(':id', $task_id);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        $task = $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        // Task not found
        $message = "Task not found.";
        $messageType = "error";
        header("Refresh: 2; URL=index.php");
    }
} catch (PDOException $e) {
    $message = "Database Error: " . $e->getMessage();
    $messageType = "error";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Task - CyberStudy</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;700;900&family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --neon-green: #39FF14;
            --neon-blue: #00F3FF;
            --neon-purple: #B967FF;
            --dark-bg: #0a0a12;
            --darker-bg: #050509;
            --card-bg: rgba(26, 26, 36, 0.8);
            --input-bg: rgba(34, 34, 48, 0.6);
            --glow-intensity: 8px;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background-color: var(--dark-bg);
            color: #fff;
            font-family: 'Rajdhani', sans-serif;
            line-height: 1.6;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(57, 255, 20, 0.05) 0%, transparent 20%),
                radial-gradient(circle at 90% 70%, rgba(0, 243, 255, 0.05) 0%, transparent 20%),
                radial-gradient(circle at 50% 30%, rgba(185, 103, 255, 0.05) 0%, transparent 30%);
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        .cyber-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
        }
        
        /* Header Styles */
        .cyber-header {
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            position: relative;
        }
        
        .cyber-header::before {
            content: '';
            position: absolute;
            bottom: 0;
            left: 20%;
            right: 20%;
            height: 3px;
            background: linear-gradient(90deg, transparent, var(--neon-green), var(--neon-blue), var(--neon-purple), transparent);
            border-radius: 100%;
        }
        
        .cyber-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 3rem;
            font-weight: 900;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 2px;
            background: linear-gradient(45deg, var(--neon-green), var(--neon-blue), var(--neon-purple));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            text-shadow: 0 0 15px rgba(57, 255, 20, 0.5);
        }
        
        .cyber-subtitle {
            font-size: 1.2rem;
            color: rgba(255, 255, 255, 0.8);
            font-weight: 300;
            letter-spacing: 3px;
        }
        
        /* Card Styles */
        .cyber-card {
            background: var(--card-bg);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 0 25px rgba(57, 255, 20, 0.15);
            border: 1px solid rgba(57, 255, 20, 0.1);
            backdrop-filter: blur(10px);
            margin-bottom: 30px;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(57, 255, 20, 0.3);
        }
        
        .card-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.8rem;
            color: var(--neon-green);
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .card-icon {
            font-size: 2rem;
            color: var(--neon-green);
        }
        
        /* Form Styles */
        .cyber-form {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group.full-width {
            grid-column: 1 / -1;
        }
        
        .form-label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: var(--neon-blue);
            font-size: 1.1rem;
        }
        
        .form-input, .form-select, .form-textarea {
            width: 100%;
            padding: 15px;
            border: 1px solid rgba(57, 255, 20, 0.3);
            border-radius: 8px;
            background-color: var(--input-bg);
            color: var(--neon-green);
            font-family: 'Rajdhani', sans-serif;
            font-size: 1.1rem;
            transition: all 0.3s ease;
        }
        
        .form-input:focus, .form-select:focus, .form-textarea:focus {
            outline: none;
            border-color: var(--neon-green);
            box-shadow: 0 0 15px rgba(57, 255, 20, 0.5);
        }
        
        .form-textarea {
            min-height: 120px;
            resize: vertical;
        }
        
        .btn-add {
            grid-column: 1 / -1;
            padding: 15px;
            background: linear-gradient(45deg, var(--neon-green), var(--neon-blue));
            color: #000;
            border: none;
            border-radius: 8px;
            font-size: 1.2rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-family: 'Orbitron', sans-serif;
        }
        
        .btn-add:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 20px rgba(57, 255, 20, 0.7);
        }
        
        /* Alert Styles */
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            font-weight: 500;
            font-size: 1.1rem;
        }
        
        .alert-success {
            background-color: rgba(57, 255, 20, 0.1);
            border: 1px solid var(--neon-green);
            color: var(--neon-green);
        }
        
        .alert-error {
            background-color: rgba(255, 20, 20, 0.1);
            border: 1px solid #ff1414;
            color: #ff1414;
        }
        
        /* Back Link */
        .back-link {
            display: inline-flex;
            align-items: center;
            margin-bottom: 25px;
            color: var(--neon-green);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            padding: 12px 20px;
            border: 1px solid var(--neon-green);
            border-radius: 8px;
            background-color: rgba(57, 255, 20, 0.1);
            font-family: 'Orbitron', sans-serif;
            letter-spacing: 1px;
            text-transform: uppercase;
        }
        
        .back-link i {
            margin-right: 10px;
        }
        
        .back-link:hover {
            transform: translateX(-5px);
            background-color: rgba(57, 255, 20, 0.2);
            box-shadow: 0 0 15px rgba(57, 255, 20, 0.3);
        }
        
        /* Footer */
        .cyber-footer {
            text-align: center;
            margin-top: 40px;
            padding: 20px;
            border-top: 1px solid rgba(57, 255, 20, 0.1);
            color: rgba(255, 255, 255, 0.5);
            font-size: 0.9rem;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .cyber-form {
                grid-template-columns: 1fr;
            }
            
            .cyber-title {
                font-size: 2.2rem;
            }
            
            .cyber-subtitle {
                font-size: 1rem;
            }
        }
        
        /* Animation */
        @keyframes glow {
            0% { box-shadow: 0 0 5px var(--neon-green); }
            50% { box-shadow: 0 0 20px var(--neon-green); }
            100% { box-shadow: 0 0 5px var(--neon-green); }
        }
        
        .glow-effect {
            animation: glow 2s infinite;
        }
    </style>
</head>
<body>
    <div class="cyber-container">
        <header class="cyber-header">
            <h1 class="cyber-title">CyberStudy</h1>
            <p class="cyber-subtitle">EDIT TASK</p>
        </header>

        <main>
            <a href="index.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
            
            <section class="cyber-card">
                <?php if (!empty($message)): ?>
                    <div class="alert alert-<?php echo $messageType; ?>">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>

                <div class="card-header">
                    <h2 class="card-title">Edit Study Task</h2>
                    <i class="fas fa-edit card-icon"></i>
                </div>
                
                <?php if ($task): ?>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . '?id=' . $task_id); ?>" method="post" class="cyber-form">
                        <div class="form-group">
                            <label class="form-label">IT Subject</label>
                            <select class="form-select" name="subject" required>
                                <option value="">Select an IT subject</option>
                                <option value="Cybersecurity" <?php echo ($task['subject'] == 'Cybersecurity') ? 'selected' : ''; ?>>Cybersecurity</option>
                                <option value="Networking" <?php echo ($task['subject'] == 'Networking') ? 'selected' : ''; ?>>Networking</option>
                                <option value="Programming" <?php echo ($task['subject'] == 'Programming') ? 'selected' : ''; ?>>Programming</option>
                                <option value="Database Management" <?php echo ($task['subject'] == 'Database Management') ? 'selected' : ''; ?>>Database Management</option>
                                <option value="Web Development" <?php echo ($task['subject'] == 'Web Development') ? 'selected' : ''; ?>>Web Development</option>
                                <option value="Cloud Computing" <?php echo ($task['subject'] == 'Cloud Computing') ? 'selected' : ''; ?>>Cloud Computing</option>
                                <option value="Data Analytics" <?php echo ($task['subject'] == 'Data Analytics') ? 'selected' : ''; ?>>Data Analytics</option>
                                <option value="AI & Machine Learning" <?php echo ($task['subject'] == 'AI & Machine Learning') ? 'selected' : ''; ?>>AI & Machine Learning</option>
                                <option value="Software Engineering" <?php echo ($task['subject'] == 'Software Engineering') ? 'selected' : ''; ?>>Software Engineering</option>
                                <option value="IT Project Management" <?php echo ($task['subject'] == 'IT Project Management') ? 'selected' : ''; ?>>IT Project Management</option>
                                <option value="Computer Hardware" <?php echo ($task['subject'] == 'Computer Hardware') ? 'selected' : ''; ?>>Computer Hardware</option>
                                <option value="Operating Systems" <?php echo ($task['subject'] == 'Operating Systems') ? 'selected' : ''; ?>>Operating Systems</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Priority Level</label>
                            <select class="form-select" name="priority">
                                <option value="high" <?php echo ($task['priority'] == 'high') ? 'selected' : ''; ?>>High Priority</option>
                                <option value="medium" <?php echo ($task['priority'] == 'medium') ? 'selected' : ''; ?>>Medium Priority</option>
                                <option value="low" <?php echo ($task['priority'] == 'low') ? 'selected' : ''; ?>>Low Priority</option>
                            </select>
                        </div>
                        
                        <div class="form-group full-width">
                            <label class="form-label">Task Description</label>
                            <textarea class="form-textarea" name="task" placeholder="Describe the IT task (e.g., Complete lab exercise, Study for exam, Work on project...)" required><?php echo htmlspecialchars($task['task_description']); ?></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Due Date</label>
                            <input type="date" class="form-input" name="due_date" value="<?php echo htmlspecialchars($task['due_date']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status">
                                <option value="pending" <?php echo ($task['status'] == 'pending') ? 'selected' : ''; ?>>Pending</option>
                                <option value="in_progress" <?php echo ($task['status'] == 'in_progress') ? 'selected' : ''; ?>>In Progress</option>
                                <option value="completed" <?php echo ($task['status'] == 'completed') ? 'selected' : ''; ?>>Completed</option>
                            </select>
                        </div>

                        <button type="submit" name="update_task" class="btn-add glow-effect">Update Task</button>
                    </form>
                <?php endif; ?>
            </section>
        </main>

        <footer class="cyber-footer">
            <p>&copy; <?php echo date('Y'); ?> CyberStudy - Advanced IT Study Planner. All rights reserved.</p>
        </footer>
    </div>

    <script>
        // Set minimum date to today
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date().toISOString().split('T')[0];
            document.querySelector('input[type="date"]').setAttribute('min', today);
            
            // Add glow effect to cyber elements on hover
            const cyberElements = document.querySelectorAll('.cyber-card');
            cyberElements.forEach(element => {
                element.addEventListener('mouseenter', () => {
                    element.classList.add('glow-effect');
                });
                
                element.addEventListener('mouseleave', () => {
                    element.classList.remove('glow-effect');
                });
            });
        });
    </script>
</body>
</html>