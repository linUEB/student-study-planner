<?php
// Start session for messages
session_start();

// Include database configuration
require_once 'config/database.php';

// Initialize database connection
$database = new Database();
$conn = $database->getConnection();

// Initialize variables
$message = '';
$messageType = '';

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_task'])) {
    // Validate and sanitize input
    $subject = htmlspecialchars(trim($_POST['subject']));
    $task_description = htmlspecialchars(trim($_POST['task_description']));
    $due_date = htmlspecialchars(trim($_POST['due_date']));
    $priority = isset($_POST['priority']) ? htmlspecialchars($_POST['priority']) : 'medium';
    $estimated_hours = isset($_POST['estimated_hours']) ? intval($_POST['estimated_hours']) : null;
    
    // Basic validation
    if (empty($subject) || empty($task_description) || empty($due_date)) {
        $message = "Please fill in all required fields";
        $messageType = "error";
    } else {
        try {
            // Prepare SQL statement
            $stmt = $conn->prepare("INSERT INTO student_planner (subject, task_description, due_date, priority, estimated_hours) 
                                  VALUES (:subject, :task_description, :due_date, :priority, :estimated_hours)");
            
            // Bind parameters
            $stmt->bindParam(':subject', $subject);
            $stmt->bindParam(':task_description', $task_description);
            $stmt->bindParam(':due_date', $due_date);
            $stmt->bindParam(':priority', $priority);
            $stmt->bindParam(':estimated_hours', $estimated_hours, PDO::PARAM_INT);
            
            // Execute query
            if ($stmt->execute()) {
                $message = "Task added successfully!";
                $messageType = "success";
                
                // Redirect to prevent form resubmission
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
            } else {
                $message = "Unable to add task.";
                $messageType = "error";
            }
        } catch (PDOException $e) {
            $message = "Database Error: " . $e->getMessage();
            $messageType = "error";
        }
    }
}

// Fetch existing tasks
$tasks = [];
try {
    $stmt = $conn->prepare("SELECT * FROM study_tasks ORDER BY due_date ASC");
    $stmt->execute();
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Silently handle error - might be first run before table exists
}

// Calculate statistics
$total_tasks = count($tasks);
$completed_tasks = 0;
$pending_tasks = 0;
$high_priority = 0;
$medium_priority = 0;
$low_priority = 0;

foreach ($tasks as $task) {
    if ($task['status'] == 'completed') {
        $completed_tasks++;
    } else {
        $pending_tasks++;
    }
    
    if ($task['priority'] == 'high') {
        $high_priority++;
    } elseif ($task['priority'] == 'medium') {
        $medium_priority++;
    } else {
        $low_priority++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CyberStudy - IT Study Planner</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;700;900&family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --neon-green: #39FF14;
            --neon-blue: #00F3FF;
            --neon-purple: #B967FF;
            --dark-bg: #0a0a12;
            --darker-bg: #050509;
            --card-bg: rgba(26, 26, 36, 0.8);
            --input-bg: rgba(34, 34, 48, 0.6);
            --glow-intensity: 8px;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background-color: var(--dark-bg);
            color: #fff;
            font-family: 'Rajdhani', sans-serif;
            line-height: 1.6;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(57, 255, 20, 0.05) 0%, transparent 20%),
                radial-gradient(circle at 90% 70%, rgba(0, 243, 255, 0.05) 0%, transparent 20%),
                radial-gradient(circle at 50% 30%, rgba(185, 103, 255, 0.05) 0%, transparent 30%);
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        .cyber-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
            display: grid;
            grid-template-columns: 1fr 3fr;
            gap: 25px;
        }
        
        /* Header Styles */
        .cyber-header {
            grid-column: 1 / -1;
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            position: relative;
        }
        
        .cyber-header::before {
            content: '';
            position: absolute;
            bottom: 0;
            left: 20%;
            right: 20%;
            height: 3px;
            background: linear-gradient(90deg, transparent, var(--neon-green), var(--neon-blue), var(--neon-purple), transparent);
            border-radius: 100%;
        }
        
        .cyber-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 3.5rem;
            font-weight: 900;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 2px;
            background: linear-gradient(45deg, var(--neon-green), var(--neon-blue), var(--neon-purple));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            text-shadow: 0 0 15px rgba(57, 255, 20, 0.5);
        }
        
        .cyber-subtitle {
            font-size: 1.4rem;
            color: rgba(255, 255, 255, 0.8);
            font-weight: 300;
            letter-spacing: 3px;
        }
        
        /* Alert Styles */
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            font-weight: 500;
            font-size: 1.1rem;
            grid-column: 1 / -1;
        }
        
        .alert-success {
            background-color: rgba(57, 255, 20, 0.1);
            border: 1px solid var(--neon-green);
            color: var(--neon-green);
        }
        
        .alert-error {
            background-color: rgba(255, 20, 20, 0.1);
            border: 1px solid #ff1414;
            color: #ff1414;
        }
        
        /* Sidebar Styles */
        .cyber-sidebar {
            background: var(--darker-bg);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 0 25px rgba(57, 255, 20, 0.2);
            border: 1px solid rgba(57, 255, 20, 0.1);
            position: sticky;
            top: 20px;
            height: fit-content;
        }
        
        .stats-container {
            margin-bottom: 30px;
        }
        
        .stats-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.2rem;
            margin-bottom: 20px;
            color: var(--neon-green);
            text-transform: uppercase;
            letter-spacing: 1px;
            display: flex;
            align-items: center;
        }
        
        .stats-title i {
            margin-right: 10px;
        }
        
        .stat-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .stat-label {
            color: rgba(255, 255, 255, 0.7);
        }
        
        .stat-value {
            font-weight: 600;
            color: var(--neon-green);
        }
        
        .priority-stat {
            display: flex;
            align-items: center;
            margin-bottom: 12px;
        }
        
        .priority-color {
            width: 15px;
            height: 15px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        .priority-high .priority-color {
            background-color: #ff1414;
            box-shadow: 0 0 10px #ff1414;
        }
        
        .priority-medium .priority-color {
            background-color: #ffcc00;
            box-shadow: 0 0 10px #ffcc00;
        }
        
        .priority-low .priority-color {
            background-color: #14ff4f;
            box-shadow: 0 0 10px #14ff4f;
        }
        
        .priority-label {
            flex-grow: 1;
            color: rgba(255, 255, 255, 0.7);
        }
        
        .priority-count {
            font-weight: 600;
            color: var(--neon-green);
        }
        
        /* Main Content Styles */
        .cyber-main {
            display: flex;
            flex-direction: column;
            gap: 25px;
        }
        
        .cyber-card {
            background: var(--card-bg);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 0 25px rgba(57, 255, 20, 0.15);
            border: 1px solid rgba(57, 255, 20, 0.1);
            backdrop-filter: blur(10px);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(57, 255, 20, 0.3);
        }
        
        .card-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.8rem;
            color: var(--neon-green);
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .card-icon {
            font-size: 2rem;
            color: var(--neon-green);
        }
        
        /* Form Styles */
        .cyber-form {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group.full-width {
            grid-column: 1 / -1;
            margin-bottom: 15px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: var(--neon-blue);
            font-size: 1.1rem;
        }
        
        .form-input, .form-select, .form-textarea {
            width: 100%;
            padding: 15px;
            border: 1px solid rgba(57, 255, 20, 0.3);
            border-radius: 8px;
            background-color: var(--input-bg);
            color: var(--neon-green);
            font-family: 'Rajdhani', sans-serif;
            font-size: 1.1rem;
            transition: all 0.3s ease;
        }
        
        .form-input:focus, .form-select:focus, .form-textarea:focus {
            outline: none;
            border-color: var(--neon-green);
            box-shadow: 0 0 15px rgba(57, 255, 20, 0.5);
        }
        
        .form-textarea {
            min-height: 120px;
            resize: vertical;
        }
        
        .btn-add {
            grid-column: 1 / -1;
            padding: 15px;
            background: linear-gradient(45deg, var(--neon-green), var(--neon-blue));
            color: #000;
            border: none;
            border-radius: 8px;
            font-size: 1.2rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-family: 'Orbitron', sans-serif;
        }
        
        .btn-add:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 20px rgba(57, 255, 20, 0.7);
        }
        
        /* Task List Styles */
        .tasks-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 25px;
        }
        
        .cyber-task {
            background: linear-gradient(145deg, rgba(26, 26, 36, 0.8), rgba(20, 20, 30, 0.8));
            border-radius: 12px;
            padding: 20px;
            border-left: 4px solid var(--neon-green);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .cyber-task::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--neon-green), transparent);
        }
        
        .cyber-task:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(57, 255, 20, 0.3);
        }
        
        .task-high {
            border-left-color: #ff1414;
        }
        
        .task-medium {
            border-left-color: #ffcc00;
        }
        
        .task-low {
            border-left-color: #14ff4f;
        }
        
        .task-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }
        
        .task-title {
            font-size: 1.4rem;
            font-weight: 700;
            color: var(--neon-green);
            margin-right: 10px;
        }
        
        .task-priority {
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .task-high .task-priority {
            background-color: rgba(255, 20, 20, 0.2);
            color: #ff1414;
        }
        
        .task-medium .task-priority {
            background-color: rgba(255, 204, 0, 0.2);
            color: #ffcc00;
        }
        
        .task-low .task-priority {
            background-color: rgba(20, 255, 79, 0.2);
            color: #14ff4f;
        }
        
        .task-description {
            margin-bottom: 20px;
            color: rgba(255, 255, 255, 0.8);
            line-height: 1.5;
        }
        
        .task-estimate {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            color: var(--neon-purple);
            font-size: 0.9rem;
        }
        
        .task-estimate i {
            margin-right: 8px;
        }
        
        .task-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .task-due {
            display: flex;
            align-items: center;
            color: var(--neon-blue);
            font-size: 0.9rem;
        }
        
        .task-due i {
            margin-right: 8px;
        }
        
        .task-actions {
            display: flex;
            gap: 10px;
        }
        
        .task-btn {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            font-size: 1rem;
        }
        
        .btn-edit {
            background: rgba(57, 255, 20, 0.2);
            color: var(--neon-green);
        }
        
        .btn-edit:hover {
            background: rgba(57, 255, 20, 0.4);
        }
        
        .btn-complete {
            background: rgba(20, 255, 79, 0.2);
            color: #14ff4f;
        }
        
        .btn-complete:hover {
            background: rgba(20, 255, 79, 0.4);
        }
        
        .btn-delete {
            background: rgba(255, 20, 20, 0.2);
            color: #ff1414;
        }
        
        .btn-delete:hover {
            background: rgba(255, 20, 20, 0.4);
        }
        
        /* Empty State */
        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 60px 20px;
            color: rgba(255, 255, 255, 0.5);
        }
        
        .empty-icon {
            font-size: 4rem;
            margin-bottom: 20px;
            color: var(--neon-green);
            opacity: 0.5;
        }
        
        .empty-text {
            font-size: 1.2rem;
        }
        
        /* Footer */
        .cyber-footer {
            grid-column: 1 / -1;
            text-align: center;
            margin-top: 40px;
            padding: 20px;
            border-top: 1px solid rgba(57, 255, 20, 0.1);
            color: rgba(255, 255, 255, 0.5);
            font-size: 0.9rem;
        }
        
        /* Responsive Design */
        @media (max-width: 1024px) {
            .cyber-container {
                grid-template-columns: 1fr;
            }
            
            .cyber-sidebar {
                position: static;
                margin-bottom: 20px;
            }
        }
        
        @media (max-width: 768px) {
            .cyber-form {
                grid-template-columns: 1fr;
            }
            
            .tasks-grid {
                grid-template-columns: 1fr;
            }
            
            .cyber-title {
                font-size: 2.5rem;
            }
            
            .cyber-subtitle {
                font-size: 1.1rem;
            }
        }
        
        /* Animation */
        @keyframes glow {
            0% { box-shadow: 0 0 5px var(--neon-green); }
            50% { box-shadow: 0 0 20px var(--neon-green); }
            100% { box-shadow: 0 0 5px var(--neon-green); }
        }
        
        .glow-effect {
            animation: glow 2s infinite;
        }
    </style>
</head>
<body>
    <div class="cyber-container">
        <header class="cyber-header">
            <h1 class="cyber-title">CyberStudy</h1>
            <p class="cyber-subtitle">ADVANCED IT STUDY PLANNER</p>
        </header>

        <?php if (!empty($message)): ?>
            <div class="alert alert-<?php echo $messageType; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <aside class="cyber-sidebar">
            <div class="stats-container">
                <h2 class="stats-title"><i class="fas fa-chart-network"></i> STUDY STATS</h2>
                
                <div class="stat-item">
                    <span class="stat-label">Total Tasks</span>
                    <span class="stat-value"><?php echo $total_tasks; ?></span>
                </div>
                
                <div class="stat-item">
                    <span class="stat-label">Completed</span>
                    <span class="stat-value"><?php echo $completed_tasks; ?></span>
                </div>
                
                <div class="stat-item">
                    <span class="stat-label">Pending</span>
                    <span class="stat-value"><?php echo $pending_tasks; ?></span>
                </div>
            </div>
            
            <div class="priority-stats">
                <h2 class="stats-title"><i class="fas fa-layer-group"></i> PRIORITY DISTRIBUTION</h2>
                
                <div class="priority-stat priority-high">
                    <div class="priority-color"></div>
                    <span class="priority-label">High Priority</span>
                    <span class="priority-count"><?php echo $high_priority; ?></span>
                </div>
                
                <div class="priority-stat priority-medium">
                    <div class="priority-color"></div>
                    <span class="priority-label">Medium Priority</span>
                    <span class="priority-count"><?php echo $medium_priority; ?></span>
                </div>
                
                <div class="priority-stat priority-low">
                    <div class="priority-color"></div>
                    <span class="priority-label">Low Priority</span>
                    <span class="priority-count"><?php echo $low_priority; ?></span>
                </div>
            </div>
        </aside>

        <main class="cyber-main">
            <section class="cyber-card">
                <div class="card-header">
                    <h2 class="card-title">Add New Study Task</h2>
                    <i class="fas fa-plus-circle card-icon"></i>
                </div>
                
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="cyber-form">
                    <div class="form-group">
                        <label class="form-label">IT Subject</label>
                        <select class="form-select" name="subject" required>
                            <option value="">Select an IT subject</option>
                            <option value="Cybersecurity">Cybersecurity</option>
                            <option value="Networking">Networking</option>
                            <option value="Programming">Programming</option>
                            <option value="Database Management">Database Management</option>
                            <option value="Web Development">Web Development</option>
                            <option value="Cloud Computing">Cloud Computing</option>
                            <option value="Data Analytics">Data Analytics</option>
                            <option value="AI & Machine Learning">AI & Machine Learning</option>
                            <option value="Software Engineering">Software Engineering</option>
                            <option value="IT Project Management">IT Project Management</option>
                            <option value="Computer Hardware">Computer Hardware</option>
                            <option value="Operating Systems">Operating Systems</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Priority Level</label>
                        <select class="form-select" name="priority">
                            <option value="high">High Priority</option>
                            <option value="medium" selected>Medium Priority</option>
                            <option value="low">Low Priority</option>
                        </select>
                    </div>
                    
                    <div class="form-group full-width">
                        <label class="form-label">Task Description</label>
                        <textarea class="form-textarea" name="task_description" placeholder="Describe the IT task (e.g., Complete lab exercise, Study for exam, Work on project...)" required></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Due Date</label>
                        <input type="date" class="form-input" name="due_date" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Estimated Hours</label>
                        <input type="number" class="form-input" name="estimated_hours" placeholder="e.g., 3" min="1">
                    </div>
                    
                    <button type="submit" name="add_task" class="btn-add glow-effect">Add To Study Plan</button>
                </form>
            </section>
            
            <section class="cyber-card">
                <div class="card-header">
                    <h2 class="card-title">Your Study Tasks</h2>
                    <i class="fas fa-tasks card-icon"></i>
                </div>
                
                <?php if (empty($tasks)): ?>
                    <div class="empty-state">
                        <i class="fas fa-laptop-code empty-icon"></i>
                        <p class="empty-text">No IT study tasks yet. Add your first task above!</p>
                    </div>
                <?php else: ?>
                    <div class="tasks-grid">
                        <?php foreach ($tasks as $task): ?>
                            <div class="cyber-task task-<?php echo $task['priority']; ?>">
                                <div class="task-header">
                                    <h3 class="task-title"><?php echo htmlspecialchars($task['subject']); ?></h3>
                                    <span class="task-priority"><?php echo ucfirst($task['priority']); ?></span>
                                </div>
                                <p class="task-description"><?php echo htmlspecialchars($task['task_description']); ?></p>
                                
                                <?php if (!empty($task['estimated_hours'])): ?>
                                <div class="task-estimate">
                                    <i class="fas fa-clock"></i>
                                    <span>Est: <?php echo $task['estimated_hours']; ?> hours</span>
                                </div>
                                <?php endif; ?>
                                
                                <div class="task-footer">
                                    <div class="task-due">
                                        <i class="far fa-calendar-alt"></i>
                                        <span>Due: <?php echo date('M d, Y', strtotime($task['due_date'])); ?></span>
                                    </div>
                                    <div class="task-actions">
                                        <a href="edit_task.php?id=<?php echo $task['id']; ?>" class="task-btn btn-edit"><i class="fas fa-edit"></i></a>
                                        <a href="mark_complete.php?id=<?php echo $task['id']; ?>" class="task-btn btn-complete"><i class="fas fa-check"></i></a>
                                        <a href="delete_task.php?id=<?php echo $task['id']; ?>" class="task-btn btn-delete" onclick="return confirm('Are you sure you want to delete this task?');"><i class="fas fa-trash"></i></a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>
        </main>
        
        <footer class="cyber-footer">
            <p>&copy; <?php echo date('Y'); ?> CyberStudy - Advanced IT Study Planner. All rights reserved.</p>
        </footer>
    </div>

    <script>
        // Set default due date to tomorrow
        document.addEventListener('DOMContentLoaded', function() {
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            const formattedDate = tomorrow.toISOString().split('T')[0];
            document.querySelector('input[name="due_date"]').value = formattedDate;
            
            // Add glow effect to cyber elements on hover
            const cyberElements = document.querySelectorAll('.cyber-task, .cyber-card');
            cyberElements.forEach(element => {
                element.addEventListener('mouseenter', () => {
                    element.classList.add('glow-effect');
                });
                
                element.addEventListener('mouseleave', () => {
                    element.classList.remove('glow-effect');
                });
            });
        });
    </script>
</body>
</html>